/* Author: Daeshaun Morrison, class of 2024
 Date: 2/9/2020
 Instructor: Professor Hellsing
 Description: This program calculates the area of a rectangle via user inputs
*/

import java.util.Scanner; // To be able to read from keyboard
public class Area {
    public static void  main (String [] args) {
//        Create  a Scanner object to read user input from keyboard
        Scanner keyboard = new Scanner(System.in);
//        Identifier declarations
        double firstSide;
        double secondSide;

//        display prompt and get input from user
        System.out.print("What is the length of one side?: ");
        firstSide = keyboard.nextDouble();
        System.out.print("What is the length of the other side?: ");
        secondSide = keyboard.nextDouble();

//        calculate the area of the rect
//        if (firstSide <= 0|| secondSide <= 0){
//
//        }
        double rectArea = firstSide * secondSide;
//        display results
        System.out.println("The rectangle's area is " + rectArea);
    }
}
